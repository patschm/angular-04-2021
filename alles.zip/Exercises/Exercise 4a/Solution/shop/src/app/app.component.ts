import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<app-productgroup-list></app-productgroup-list>`,
  styles: []
})
export class AppComponent {
  title = 'shop';
}
