import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <!--TODO: 5
      Use the ProductGroupListComponent here

      Test the application (ng serve --open)
    -->
  <app-productgroup-list></app-productgroup-list>
  `,
  styles: []
})
export class AppComponent {
  title = 'shop';
}
