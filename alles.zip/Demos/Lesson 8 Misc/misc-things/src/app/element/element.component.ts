import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-element',
  templateUrl: './element.component.html',
  styleUrls: ['./element.component.css']
})
export class ElementComponent implements OnInit {

  @ViewChild("h1", { static: true })
  public ha1:ElementRef

  doClick()
  {
    this.ha1.nativeElement.textContent = "Angular elements";
  }
  constructor() { }

  ngOnInit() {
  }

}
