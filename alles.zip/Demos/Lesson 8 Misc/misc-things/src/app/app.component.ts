import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <app-element></app-element>
  `,
  styles: []
})
export class AppComponent {
  title = 'MiscThings';
}
