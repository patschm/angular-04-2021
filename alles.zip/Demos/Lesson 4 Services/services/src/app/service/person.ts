export class Person
{
  public name:string;
  public age:number;
}
