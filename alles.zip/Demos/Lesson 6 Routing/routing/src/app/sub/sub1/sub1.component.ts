import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub1',
  template: `<h1>Sub 1</h1>`,
  styles: []
})
export class Sub1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
